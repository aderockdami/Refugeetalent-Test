﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.IO;
namespace DAL
{
    public class StudentDAL
    {
        public List<StudentBO> Read(StudentBO obj, int ch)
        {
            List<StudentBO> list = new List<StudentBO>();
            try
            {
                var fileData = File.ReadAllLines("Students.txt").ToList();
                int flag = 0;
                foreach (var item in fileData)
                {
                    StudentBO bo = new StudentBO();
                    string[] data = item.Split(',');
                    if (ch == 1)
                    {
                        if (data[0] == obj.Firstname)
                        {
                            flag = 1;
                            bo.Firstname = data[0];
                            bo.Lastname = data[1];
                            bo.Age = Convert.ToInt32(data[2]);
                            bo.Gender = data[3];
                            bo.DOB = data[4];
                            bo.Address = data[5];
                            bo.Phone = data[6];

                            list.Add(bo);
                            break;
                        }
                    }
                    else if(ch == 2)
                    {
                        if (data[3] == obj.Gender)
                        {
                            flag = 1;
                            bo.Firstname = data[0];
                            bo.Lastname = data[1];
                            bo.Age = Convert.ToInt32(data[2]);
                            bo.Gender = data[3];
                            bo.DOB = data[4];
                            bo.Address = data[5];
                            bo.Phone = data[6];

                            list.Add(bo);
                        }
                    }
                    else if(ch == 3)
                    {
                        if (Convert.ToInt32(data[2]) > obj.Age)
                        {
                            flag = 1;
                            bo.Firstname = data[0];
                            bo.Lastname = data[1];
                            bo.Age = Convert.ToInt32(data[2]);
                            bo.Gender = data[3];
                            bo.DOB = data[4];
                            bo.Address = data[5];
                            bo.Phone = data[6];

                            list.Add(bo);
                        }
                    }
                }

                if (flag == 0)
                    Console.WriteLine("No Student Found With this name.");
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("File Not Found.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro Occurred.");
            }

            return list;
        }

        public void UpdateStudent(StudentBO bo)
        {
            try
            {
                var fileData = File.ReadAllLines("Students.txt");
                int flag = 0;
                int count = 0;
                foreach (var item in fileData)
                {
                    string[] data = item.Split(',');
                    if (data[0] == bo.Firstname)
                    {
                        flag = 1;
                        Console.Write("\n\nEnter New First Name : ");
                        data[0] = Console.ReadLine();
                        Console.Write("Enter New Last Name : ");
                        data[1] = Console.ReadLine();
                        Console.Write("Enter New Student Age : ");
                        data[2] = Console.ReadLine();
                        Console.Write("Enter New Student Gender : ");
                        data[3] = Console.ReadLine();
                        Console.Write("Enter New Student Date of Birth 'dd/mm/yyyy' : ");
                        data[4] = Console.ReadLine();
                        Console.Write("Enter New Student Address : ");
                        data[5] = Console.ReadLine();
                        Console.Write("Enter New Student Phone : ");
                        data[6] = Console.ReadLine();

                        string updatedLine = data[0] + "," + data[1] + "," + data[2] + "," + data[3] + "," + data[4]
                        + "," + data[5] + "," + data[6];
                        fileData[count] = updatedLine;


                        FileStream fout = new FileStream("Students.txt", FileMode.Open);
                        StreamWriter sw = new StreamWriter(fout);

                        foreach (var student in fileData)
                        {
                            sw.WriteLine(student);
                        }

                        sw.Close();
                        fout.Close();
                        Console.WriteLine("\nRecord Updated Successfully !");
                        break;
                    }
                    count++;
                }

                if (flag == 0)
                    Console.WriteLine("No Student Found With this name.");
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("File Not Found.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro Occurred.");
            }
        }
        public void Save(StudentBO bo)
        {
            try
            {
                //save in file
                FileStream fout = new FileStream("Students.txt", FileMode.Append);
                StreamWriter sw = new StreamWriter(fout);

                sw.WriteLine(bo.Firstname + "," + bo.Lastname + "," + bo.Age + "," + bo.Gender + "," + bo.DOB
                    + "," + bo.Address + "," + bo.Phone);
                sw.Close();
                fout.Close();
                Console.WriteLine("\nRecord Added Successfully !");
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nError Adding Record !");
            }



        }
        public void DeleteStudent(StudentBO bo)
        {
            try
            {
                var fileData = File.ReadAllLines("Students.txt").ToList();
                int flag = 0;
                int count = 0;
                foreach (var item in fileData)
                {
                    string[] data = item.Split(',');
                    if (data[0] == bo.Firstname)
                    {
                        File.Delete("Students.txt");
                        flag = 1;
                        fileData.Remove(item);


                        FileStream fout = new FileStream("Students.txt", FileMode.Append);
                        StreamWriter sw = new StreamWriter(fout);

                        foreach (var student in fileData)
                        {
                            sw.WriteLine(student);
                        }

                        sw.Close();
                        fout.Close();
                        Console.WriteLine("\nRecord Deleted Successfully !");
                        break;
                    }
                    count++;
                }

                if (flag == 0)
                    Console.WriteLine("No Student Found With this name.");
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("File Not Found.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro Occurred.");
            }

        }
    }
}
