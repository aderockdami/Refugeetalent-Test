﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DAL;
namespace BLL
{
    public class StudentBLL
    {
        public List<StudentBO> Read(StudentBO bo, int ch)
        {
            StudentDAL dal = new StudentDAL();

            return dal.Read(bo,ch);
        }
        public void Save(StudentBO bo)
        {
            StudentDAL dal = new StudentDAL();
            dal.Save(bo);
        }
        public void UpdateStudent(StudentBO bo)
        {
            StudentDAL dal = new StudentDAL();
            dal.UpdateStudent(bo);
        }
        public void DeleteStudent(StudentBO bo)
        {
            StudentDAL dal = new StudentDAL();
            dal.DeleteStudent(bo);
        }


    }
}
