﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using BLL;
namespace PL
{
    public class StudentView
    {
        StudentBLL Studentbl = new StudentBLL();
        public int Menu()
        {
            int choice;
            Console.WriteLine("\t***************************************");
            Console.WriteLine("\t WELCOME TO STUDENT INFORMATION SYSTEM");
            Console.WriteLine("\t***************************************");
            Console.WriteLine("\n\nPlease Input:\n1. Add New Student.\n2. Update Student Information.");
            Console.WriteLine("3. Delete Student Record.\n4. Search Student.\nYour Choice");
            choice = Convert.ToInt32(Console.ReadLine());

            if(choice > 4 || choice < 1)
            {
                do
                {
                    Console.Write("Invalid Input ! Please try again.\nYour choice.");
                    choice = Convert.ToInt32(Console.ReadLine());
                } while (choice > 4 || choice < 1);
            }
            return choice;
        }
        public void AddNewStudent()
        {
            StudentBO bo = new StudentBO();
            Console.Clear();
            Console.Write("\n\nEnter First Name : ");
            bo.Firstname = Console.ReadLine();
            Console.Write("Enter Last Name : ");
            bo.Lastname = Console.ReadLine();
            Console.Write("Enter Student Age : ");
            bo.Age = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Student Gender : ");
            bo.Gender = Console.ReadLine();
            Console.Write("Enter Student Date of Birth 'dd/mm/yyyy' : ");
            bo.DOB = Console.ReadLine();
            Console.Write("Enter Student Address : ");
            bo.Address = Console.ReadLine();
            Console.Write("Enter Student Phone : ");
            bo.Phone = Console.ReadLine();
            
            Studentbl.Save(bo);
        }

        public void UpdateStudent()
        {
            StudentBO bo = new StudentBO();
            Console.Clear();
            Console.Write("Enter Student First Name to Update : ");
            bo.Firstname = Console.ReadLine();
            Studentbl.UpdateStudent(bo);
        }
        public void DeleteStudent()
        {
            StudentBO bo = new StudentBO();
            Console.Clear();
            Console.Write("Enter Student First Name to Delete Record : ");
            bo.Firstname = Console.ReadLine();
            Studentbl.DeleteStudent(bo);
        }
        public void Display()
        {
            Console.Clear();
            Console.WriteLine("Please Press,\n1. Search By First Name.\n2. Search By Gender.\n3. Search by Older than Age");
            int ch = Convert.ToInt32(Console.ReadLine());
            StudentBO obj = new StudentBO();
            StudentBLL bl = new StudentBLL();
            List<StudentBO> bo = new List<StudentBO>();

            switch (ch)
            {
                case 1:
                    Console.Write("Enter Student First Name to Search Record : ");
                    obj.Firstname = Console.ReadLine();
                    bo = bl.Read(obj,ch);
                    break;
                case 2:
                    Console.Write("Enter Student Gender Search Record{s) : ");
                    obj.Gender = Console.ReadLine();
                    bo = bl.Read(obj, ch);
                    break;
                case 3:
                    Console.Write("Enter Student Age Search Record{s) : ");
                    obj.Age = Convert.ToInt32(Console.ReadLine());
                    bo = bl.Read(obj, ch);
                    break;
                default:
                    Console.WriteLine("Invalid Input..!");
                    break;
            }
            
            
            
            if(bo.Count > 0)
            {
                Console.WriteLine("Displaying Records..!\n");
                foreach (var _bo in bo)
                {

                    Console.WriteLine("\n\nFirst Name  = " + _bo.Firstname);
                    Console.WriteLine("Last Name  = " + _bo.Lastname);
                    Console.WriteLine("Age  = " + _bo.Age);
                    Console.WriteLine("Gender  = " + _bo.Gender);
                    Console.WriteLine("Date Of Birth  = " + _bo.DOB);
                    Console.WriteLine("Address  = " + _bo.Address);
                    Console.WriteLine("Contact  = " + _bo.Phone);
                }
            }
               
            
        }

    }
}
