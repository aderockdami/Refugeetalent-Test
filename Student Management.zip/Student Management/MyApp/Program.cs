﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PL;
namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            char ch = 'Y';
            
            while(ch == 'y' || ch =='Y')
            {
                Console.Clear();
                StudentView view = new StudentView();
                int userChoice = view.Menu();

                switch (userChoice)
                {
                    case 1:
                        view.AddNewStudent();
                        break;
                    case 2:
                        view.UpdateStudent();
                        break;
                    case 3:
                        view.DeleteStudent();
                        break;
                    case 4:
                        view.Display();
                        break;
                    default:
                        break;
                }
                Console.WriteLine("Presee Y to continue or any key to exit !");
                ch = Console.ReadKey().KeyChar;
            }
            
            //view.Input();
            //view.Display();

            Console.ReadKey();
        }
    }
}
